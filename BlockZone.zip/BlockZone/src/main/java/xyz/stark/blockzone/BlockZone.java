package xyz.stark.blockzone;

import io.papermc.paper.event.block.BlockDamageAbortEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class BlockZone extends JavaPlugin implements Listener, TabExecutor {

    private static final int CENTER_SLOT = 13;

    static class Zone {
        String name, world;
        int x1, y1, z1, x2, y2, z2;
        Material material;
        String enchant;
        int required = 1;
        int speed = 1;

        boolean contains(Block b) {
            return b.getWorld().getName().equals(world)
                    && b.getX() >= x1 && b.getX() <= x2
                    && b.getY() >= y1 && b.getY() <= y2
                    && b.getZ() >= z1 && b.getZ() <= z2;
        }
    }

    static class GuiHolder implements InventoryHolder {
        final String zone;
        Inventory inv;
        GuiHolder(String zone) { this.zone = zone; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final Map<String, Zone> zones = new LinkedHashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private final Set<UUID> hasted = new HashSet<>();
    private NamespacedKey wandKey;
    private File zonesFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "wand");
        zonesFile = new File(getDataFolder(), "zones.yml");
        loadZones();
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("blockzone");
        cmd.setExecutor(this);
        cmd.setTabCompleter(this);
    }

    @Override
    public void onDisable() {
        saveZones();
    }

    // ---------------- Storage ----------------

    private void loadZones() {
        zones.clear();
        if (!zonesFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(zonesFile);
        ConfigurationSection root = y.getConfigurationSection("zones");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            Zone z = new Zone();
            z.name = key;
            z.world = s.getString("world");
            z.x1 = s.getInt("x1"); z.y1 = s.getInt("y1"); z.z1 = s.getInt("z1");
            z.x2 = s.getInt("x2"); z.y2 = s.getInt("y2"); z.z2 = s.getInt("z2");
            String m = s.getString("material");
            z.material = m == null ? null : Material.matchMaterial(m);
            z.enchant = s.getString("enchant");
            z.required = s.getInt("required", 1);
            z.speed = s.getInt("speed", 1);
            zones.put(key.toLowerCase(), z);
        }
    }

    private void saveZones() {
        YamlConfiguration y = new YamlConfiguration();
        for (Zone z : zones.values()) {
            String p = "zones." + z.name + ".";
            y.set(p + "world", z.world);
            y.set(p + "x1", z.x1); y.set(p + "y1", z.y1); y.set(p + "z1", z.z1);
            y.set(p + "x2", z.x2); y.set(p + "y2", z.y2); y.set(p + "z2", z.z2);
            y.set(p + "material", z.material == null ? null : z.material.name());
            y.set(p + "enchant", z.enchant);
            y.set(p + "required", z.required);
            y.set(p + "speed", z.speed);
        }
        try {
            getDataFolder().mkdirs();
            y.save(zonesFile);
        } catch (IOException e) {
            getLogger().warning("Failed to save zones.yml: " + e.getMessage());
        }
    }

    // ---------------- Helpers ----------------

    private void msg(CommandSender s, String text) {
        s.sendMessage(Component.text("[BlockZone] ", NamedTextColor.GOLD)
                .append(Component.text(text, NamedTextColor.YELLOW)));
    }

    private Enchantment findEnchant(String name) {
        return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(name.toLowerCase()));
    }

    private ItemStack createWand() {
        ItemStack it = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("BlockZone Wand", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("Left-click = position 1", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Right-click = position 2", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isWand(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    private void openGui(Player p, Zone z) {
        GuiHolder holder = new GuiHolder(z.name);
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("Place the block - " + z.name, NamedTextColor.DARK_GRAY));
        holder.inv = inv;
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta m = glass.getItemMeta();
        m.displayName(Component.text(" "));
        glass.setItemMeta(m);
        for (int i = 0; i < 27; i++) if (i != CENTER_SLOT) inv.setItem(i, glass);
        p.openInventory(inv);
    }

    private int fillZone(Zone z) {
        World w = Bukkit.getWorld(z.world);
        if (w == null || z.material == null) return -1;
        long vol = (long) (z.x2 - z.x1 + 1) * (z.y2 - z.y1 + 1) * (z.z2 - z.z1 + 1);
        if (vol > getConfig().getLong("max-fill-blocks", 200000)) return -2;
        for (int x = z.x1; x <= z.x2; x++)
            for (int y = z.y1; y <= z.y2; y++)
                for (int zz = z.z1; zz <= z.z2; zz++)
                    w.getBlockAt(x, y, zz).setType(z.material, false);
        return (int) vol;
    }

    private Zone zoneAt(Block b) {
        for (Zone z : zones.values()) if (z.contains(b)) return z;
        return null;
    }

    // ---------------- Commands ----------------

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("blockzone.admin")) { msg(s, "You do not have permission."); return true; }
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            sendHelp(s);
            return true;
        }
        String sub = a[0].toLowerCase();
        switch (sub) {
            case "wand" -> {
                if (!(s instanceof Player p)) return true;
                p.getInventory().addItem(createWand());
                msg(s, "You got the wand. Left-click = position 1, right-click = position 2.");
            }
            case "create" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 2) { msg(s, "Usage: /bz create <name>"); return true; }
                Location[] sel = selections.get(p.getUniqueId());
                if (sel == null || sel[0] == null || sel[1] == null) { msg(s, "Select both positions with the wand first."); return true; }
                if (!sel[0].getWorld().equals(sel[1].getWorld())) { msg(s, "Both positions must be in the same world."); return true; }
                Zone z = new Zone();
                z.name = a[1];
                z.world = sel[0].getWorld().getName();
                z.x1 = Math.min(sel[0].getBlockX(), sel[1].getBlockX());
                z.y1 = Math.min(sel[0].getBlockY(), sel[1].getBlockY());
                z.z1 = Math.min(sel[0].getBlockZ(), sel[1].getBlockZ());
                z.x2 = Math.max(sel[0].getBlockX(), sel[1].getBlockX());
                z.y2 = Math.max(sel[0].getBlockY(), sel[1].getBlockY());
                z.z2 = Math.max(sel[0].getBlockZ(), sel[1].getBlockZ());
                zones.put(a[1].toLowerCase(), z);
                saveZones();
                msg(s, "Zone " + a[1] + " created. Use /bz gui " + a[1]);
            }
            case "gui" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 2) { msg(s, "Usage: /bz gui <name>"); return true; }
                Zone z = zones.get(a[1].toLowerCase());
                if (z == null) { msg(s, "Zone not found."); return true; }
                openGui(p, z);
            }
            case "enchant" -> {
                if (a.length < 5) { msg(s, "Usage: /bz enchant <name> <enchant> <required level> <speed>  (example: /bz enchant mine efficiency 3 5)"); return true; }
                Zone z = zones.get(a[1].toLowerCase());
                if (z == null) { msg(s, "Zone not found."); return true; }
                Enchantment e = findEnchant(a[2]);
                if (e == null) { msg(s, "Invalid enchantment: " + a[2]); return true; }
                int req, spd;
                try {
                    req = Integer.parseInt(a[3]);
                    spd = Integer.parseInt(a[4]);
                } catch (NumberFormatException ex) { msg(s, "Required level and speed must be numbers."); return true; }
                if (req < 1 || spd < 1 || spd > 255) { msg(s, "Invalid values."); return true; }
                z.enchant = a[2].toLowerCase();
                z.required = req;
                z.speed = spd;
                saveZones();
                msg(s, "Set: " + z.enchant + " level " + req + " required, mining speed (Haste) = " + spd);
            }
            case "clear" -> {
                if (a.length < 2) return true;
                Zone z = zones.get(a[1].toLowerCase());
                if (z == null) { msg(s, "Zone not found."); return true; }
                z.enchant = null;
                saveZones();
                msg(s, "Enchantment requirement removed.");
            }
            case "info" -> {
                if (a.length < 2) return true;
                Zone z = zones.get(a[1].toLowerCase());
                if (z == null) { msg(s, "Zone not found."); return true; }
                msg(s, z.name + " | " + z.world + " | (" + z.x1 + "," + z.y1 + "," + z.z1 + ") -> (" + z.x2 + "," + z.y2 + "," + z.z2 + ")");
                msg(s, "Block: " + z.material + " | Enchant: " + z.enchant + " | Required: " + z.required + " | Speed: " + z.speed);
            }
            case "list" -> msg(s, zones.isEmpty() ? "No zones." : zones.values().stream().map(z -> z.name).collect(Collectors.joining(", ")));
            case "delete" -> {
                if (a.length < 2) return true;
                if (zones.remove(a[1].toLowerCase()) != null) { saveZones(); msg(s, "Zone deleted."); }
                else msg(s, "Zone not found.");
            }
            case "reload" -> {
                reloadConfig();
                loadZones();
                msg(s, "Reloaded.");
            }
            default -> msg(s, "Unknown command. Use /bz help");
        }
        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage(Component.text("========== BlockZone Help ==========", NamedTextColor.GOLD));
        String[][] cmds = {
            {"/bz help", "Show this help message."},
            {"/bz wand", "Get the selection wand. Left-click a block = position 1, right-click a block = position 2."},
            {"/bz create <name>", "Create a zone from your two selected positions."},
            {"/bz gui <name>", "Open the glass GUI. Put a block in the middle slot and close the GUI to fill the whole zone with that block."},
            {"/bz enchant <name> <enchant> <required level> <speed>", "Set the enchantment requirement. Players mining the zone block with a tool that has this enchantment at the required level or higher get Haste at the given speed level. Example: /bz enchant mine efficiency 4 2"},
            {"/bz clear <name>", "Remove the enchantment requirement from a zone."},
            {"/bz info <name>", "Show zone details (world, positions, block, enchantment, required level, speed)."},
            {"/bz list", "List all zones."},
            {"/bz delete <name>", "Delete a zone (blocks are not removed)."},
            {"/bz reload", "Reload config.yml and zones.yml."},
        };
        for (String[] c : cmds) {
            s.sendMessage(Component.text(c[0], NamedTextColor.YELLOW)
                    .append(Component.text(" - " + c[1], NamedTextColor.GRAY)));
        }
        s.sendMessage(Component.text("Aliases: /blockzone, /bz  |  Permission: blockzone.admin", NamedTextColor.DARK_GRAY));
        s.sendMessage(Component.text("Config: deny-if-not-met (true = players without the required enchant cannot break the block).", NamedTextColor.DARK_GRAY));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1)
            return filter(List.of("help", "wand", "create", "gui", "enchant", "clear", "info", "list", "delete", "reload"), a[0]);
        if (a.length == 2 && List.of("gui", "enchant", "clear", "info", "delete").contains(a[0].toLowerCase()))
            return filter(zones.values().stream().map(z -> z.name).toList(), a[1]);
        if (a.length == 3 && a[0].equalsIgnoreCase("enchant"))
            return filter(StreamSupportKeys(), a[2]);
        return List.of();
    }

    private List<String> StreamSupportKeys() {
        List<String> out = new ArrayList<>();
        for (Enchantment e : Registry.ENCHANTMENT) out.add(e.getKey().getKey());
        return out;
    }

    private List<String> filter(List<String> list, String prefix) {
        return list.stream().filter(x -> x.toLowerCase().startsWith(prefix.toLowerCase())).collect(Collectors.toList());
    }

    // ---------------- Wand ----------------

    @EventHandler
    public void onWand(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!isWand(e.getItem())) return;
        if (!e.getPlayer().hasPermission("blockzone.admin")) return;
        if (e.getClickedBlock() == null) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        e.setCancelled(true);
        Location[] sel = selections.computeIfAbsent(e.getPlayer().getUniqueId(), k -> new Location[2]);
        Location loc = e.getClickedBlock().getLocation();
        if (a == Action.LEFT_CLICK_BLOCK) {
            sel[0] = loc;
            msg(e.getPlayer(), "Position 1: " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
        } else {
            sel[1] = loc;
            msg(e.getPlayer(), "Position 2: " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
        }
    }

    // ---------------- GUI ----------------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GuiHolder)) return;
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
        if (e.getClickedInventory() == e.getView().getTopInventory() && e.getSlot() != CENTER_SLOT)
            e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GuiHolder)) return;
        for (int slot : e.getRawSlots())
            if (slot < 27 && slot != CENTER_SLOT) { e.setCancelled(true); return; }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof GuiHolder holder)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        ItemStack it = e.getInventory().getItem(CENTER_SLOT);
        if (it == null || it.getType().isAir()) return;
        e.getInventory().setItem(CENTER_SLOT, null);

        Zone z = zones.get(holder.zone.toLowerCase());
        Material m = it.getType();
        // give the item back to the player
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));

        if (z == null) return;
        if (!m.isBlock() || !m.isSolid()) { msg(p, "That is not a valid block."); return; }
        z.material = m;
        saveZones();
        int n = fillZone(z);
        if (n == -2) msg(p, "The zone is larger than the allowed limit (max-fill-blocks).");
        else if (n < 0) msg(p, "The world is not loaded.");
        else msg(p, "Zone filled with " + m.name() + " (" + n + " blocks).");
    }

    // ---------------- Mining ----------------

    @EventHandler
    public void onDamage(BlockDamageEvent e) {
        Block b = e.getBlock();
        Zone z = zoneAt(b);
        if (z == null || z.enchant == null || z.material == null || b.getType() != z.material) return;
        Player p = e.getPlayer();
        Enchantment ench = findEnchant(z.enchant);
        if (ench == null) return;
        int lvl = p.getInventory().getItemInMainHand().getEnchantmentLevel(ench);
        if (lvl >= z.required) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 200, z.speed - 1, false, false, false));
            hasted.add(p.getUniqueId());
        } else if (getConfig().getBoolean("deny-if-not-met", false)) {
            e.setCancelled(true);
            p.sendActionBar(Component.text("You need " + z.enchant + " level " + z.required, NamedTextColor.RED));
        }
    }

    private void removeHaste(Player p) {
        if (hasted.remove(p.getUniqueId())) p.removePotionEffect(PotionEffectType.HASTE);
    }

    @EventHandler
    public void onAbort(BlockDamageAbortEvent e) { removeHaste(e.getPlayer()); }

    @EventHandler
    public void onBreak(BlockBreakEvent e) { removeHaste(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { removeHaste(e.getPlayer()); }
}
